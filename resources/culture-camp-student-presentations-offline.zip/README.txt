MATCHBOOK CULTURE CAMP - STUDENT PRESENTATION LIBRARY

1. Unzip this folder before presenting.
2. Open student-decks-index.html in Chrome, Edge, Firefox, or Safari.
3. Choose the session and grade band.
4. Use the arrow keys or space bar to advance slides. Press N for presenter notes.

All fonts, icons, scripts, and images required by the presentations are included.
The library works without an internet connection after it has been downloaded and unzipped.